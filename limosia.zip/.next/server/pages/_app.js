(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9892:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Karla_e0dfb4', '__Karla_Fallback_e0dfb4'","fontStyle":"normal"},
	"className": "__className_e0dfb4"
};


/***/ }),

/***/ 9014:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Raleway_e42c30', '__Raleway_Fallback_e42c30'","fontStyle":"normal"},
	"className": "__className_e42c30"
};


/***/ }),

/***/ 8243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* reexport */ App)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"pages\\_app.js","import":"Raleway","arguments":[{"subsets":["latin"]}],"variableName":"raleway"}
var target_path_pages_app_js_import_Raleway_arguments_subsets_latin_variableName_raleway_ = __webpack_require__(9014);
var target_path_pages_app_js_import_Raleway_arguments_subsets_latin_variableName_raleway_default = /*#__PURE__*/__webpack_require__.n(target_path_pages_app_js_import_Raleway_arguments_subsets_latin_variableName_raleway_);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"pages\\_app.js","import":"Karla","arguments":[{"subsets":["latin"]}],"variableName":"karla"}
var target_path_pages_app_js_import_Karla_arguments_subsets_latin_variableName_karla_ = __webpack_require__(9892);
var target_path_pages_app_js_import_Karla_arguments_subsets_latin_variableName_karla_default = /*#__PURE__*/__webpack_require__.n(target_path_pages_app_js_import_Karla_arguments_subsets_latin_variableName_karla_);
;// CONCATENATED MODULE: external "styled-jsx/style"
const style_namespaceObject = require("styled-jsx/style");
var style_default = /*#__PURE__*/__webpack_require__.n(style_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Footer.jsx



const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full px-[80px] py-20 h-auto flex justify-around items-start flex-row bg-black",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "pl-4 pr-16 py-2 w-[40%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                className: " text-[24px] text-white raleway font-bold mb-8",
                                children: "About Us"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-[#868686] text-[12px] karla",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: "Lorem ipsum dolor sit amet, consectetur adipisc ing elit, sed do eiusmod seta incididunt ut labore magna lorem ipsum dolor sit amet."
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut du aute irure dolor in reprehenderit."
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: "Lorem ipsum dolor sit amet, ctetur elitse adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "px-4 py-2 w-[20%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                className: "text-[24px] text-white raleway font-bold mb-8",
                                children: "Useful Links"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "text-[#868686] text-[12px] karla",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "About Us"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Services"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Vehicles"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Our Client"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Reservation"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Contact"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "px-4 py-2 w-[20%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                className: "text-[24px] text-white raleway font-bold mb-8",
                                children: "Contact Us"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "text-[#868686] text-[12px] karla",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "mb-2",
                                        children: "(+40) 74 0920 2288"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "mb-2",
                                        children: "office@rentacar.com"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "mb-2",
                                        children: "New York 11673 Collins Street West Victoria United State."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "px-4 py-2 w-[20%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                className: "text-[24px] text-white raleway font-bold mb-8",
                                children: "Services"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "text-[#868686] text-[12px] karla",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Daily Rent Car"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Monthly Rent Car"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Tour & Travel Car"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: "Rent Truck"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full px-[80px] border-t border-solid border-[#868686] py-6 h-auto flex justify-between items-center flex-row bg-black",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "relative w-[10vw] h-[5vh] self-start",
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: "/assets/limosia-logo.png",
                            alt: "logo",
                            fill: true,
                            className: "object-contain"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "karla text-[#868686] text-[12px]",
                        children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                            children: "Copyright \xa9 2023 Limosia, All rights reserved."
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Navbar.jsx




const Navbar = ()=>{
    const links = [
        {
            names: "Home",
            link: "/"
        },
        {
            names: "Car Class",
            link: "/car-class"
        },
        {
            names: "About",
            link: "/#"
        },
        {
            names: "Our Client",
            link: "/#"
        },
        {
            names: "Contact",
            link: "/#"
        },
        {
            names: "My Account",
            link: "/login"
        }
    ];
    const [scroll, setScroll] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const changeColor = ()=>{
            if (window.scrollY > 90) {
                setScroll(true);
            // setColor("#FFFFFF");
            // setTextColor("#000000");
            // if (data) {
            //     setLogo(
            //         data.data.attributes.SecondLogo.data.attributes.url
            //     );
            // }
            } else {
                setScroll(false);
            // setColor("transparent");
            // setTextColor("#FFFFFF");
            // if (data) {
            //     setLogo(data.data.attributes.Logo.data.attributes.url);
            // }
            }
        };
        window.addEventListener("scroll", changeColor);
    }, []);
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: `fixed left-0 top-0 w-full z-10 ease-in duration-300 ${scroll ? "" : "mt-5"}`,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "max-w-[1240px] 2xl:max-w-[1768px] rounded-lg m-auto flex gap-5 items-center text-[#868686] bg-white",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                    href: "/",
                    className: "bg-[#ED7A48] px-7 py-2 rounded-l-lg",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "relative w-[140px] h-[70px]",
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: `./assets/limosia-logo.png`,
                            alt: "logo-limosia",
                            fill: true,
                            className: "object-contain",
                            unoptimized: true
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "w-full flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("ul", {
                            className: "hidden sm:flex items-center gap-8",
                            children: links && links.map((item, index)=>{
                                return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
                                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "group",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: "py-2 px-2 custom-link uppercase",
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: item.link,
                                                    className: "text-[16px] karla font-bold",
                                                    children: item.names
                                                })
                                            })
                                        })
                                    }, index)
                                });
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "pr-4",
                            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "group",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                                    className: "rounded-xl border-2 border-[#868686] p-1",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                                            value: `USD`,
                                            children: "USD"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("option", {
                                            value: `THB`,
                                            children: "THB"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_Navbar = (Navbar);

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
;// CONCATENATED MODULE: ./pages/_app.js







function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            jsx_runtime.jsx((style_default()), {
                id: "574b7202fa404fff",
                dynamic: [
                    (target_path_pages_app_js_import_Raleway_arguments_subsets_latin_variableName_raleway_default()).style.fontFamily,
                    (target_path_pages_app_js_import_Karla_arguments_subsets_latin_variableName_karla_default()).style.fontFamily
                ],
                children: `.raleway{font-family:${(target_path_pages_app_js_import_Raleway_arguments_subsets_latin_variableName_raleway_default()).style.fontFamily}}.karla{font-family:${(target_path_pages_app_js_import_Karla_arguments_subsets_latin_variableName_karla_default()).style.fontFamily}}`
            }),
            /*#__PURE__*/ jsx_runtime.jsx(components_Navbar, {}),
            /*#__PURE__*/ jsx_runtime.jsx(Component, {
                ...pageProps,
                className: style_default().dynamic([
                    [
                        "574b7202fa404fff",
                        [
                            (target_path_pages_app_js_import_Raleway_arguments_subsets_latin_variableName_raleway_default()).style.fontFamily,
                            (target_path_pages_app_js_import_Karla_arguments_subsets_latin_variableName_karla_default()).style.fontFamily
                        ]
                    ]
                ]) + " " + (pageProps && pageProps.className != null && pageProps.className || "")
            }),
            /*#__PURE__*/ jsx_runtime.jsx(components_Footer, {})
        ]
    });
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-route-loader.js?page=%2F_app&absolutePagePath=private-next-pages%2F_app.js&preferredRegion=!

        // Next.js Route Loader
        
        
    

/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,664,636,675], () => (__webpack_exec__(8243)));
module.exports = __webpack_exports__;

})();